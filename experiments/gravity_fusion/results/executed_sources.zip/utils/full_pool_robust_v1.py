import torch


def transform_points(transform, points):
    return points @ transform[:3, :3].T + transform[:3, 3]


def weighted_rigid_transform(source, target, weights):
    weights = weights.clamp_min(0)
    total = weights.sum()
    if source.shape[0] < 3 or total <= 1e-8:
        raise RuntimeError("Insufficient weighted correspondences")
    source_mean = (source * weights[:, None]).sum(0) / total
    target_mean = (target * weights[:, None]).sum(0) / total
    source_centered = source - source_mean
    target_centered = target - target_mean
    covariance = source_centered.T @ (target_centered * weights[:, None])
    u, _, vh = torch.linalg.svd(covariance)
    correction = torch.eye(3, dtype=source.dtype, device=source.device)
    correction[-1, -1] = torch.det(vh.T @ u.T)
    rotation = vh.T @ correction @ u.T
    translation = target_mean - rotation @ source_mean
    transform = torch.eye(4, dtype=source.dtype, device=source.device)
    transform[:3, :3] = rotation
    transform[:3, 3] = translation
    return transform


def full_pool_refine(initial, source, target):
    transform = initial.clone()
    for threshold in (1.2, 0.6):
        residual = torch.linalg.norm(transform_points(transform, source) - target, dim=1)
        inliers = residual < threshold
        if int(inliers.sum()) < 6:
            break
        scaled_residual = residual[inliers] / threshold
        weights = (1.0 - scaled_residual.square()).clamp_min(0).square()
        transform = weighted_rigid_transform(source[inliers], target[inliers], weights)
    return transform
